package com.gkprojects.bookimggym.data.repo

class BookingRepository {
}