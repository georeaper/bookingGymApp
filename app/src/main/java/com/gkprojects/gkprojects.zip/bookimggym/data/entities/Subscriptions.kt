package com.gkprojects.bookimggym.data.entities

data class Subscriptions(
    var subscriptionName : String,  //Package of 6
    var visits : Int  //6
)
