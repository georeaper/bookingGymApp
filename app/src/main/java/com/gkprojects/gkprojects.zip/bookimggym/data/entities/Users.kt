package com.gkprojects.bookimggym.data.entities

data class Users(
    var name : String,
    var age : Int? ,
    var email : String? ,
    var phone : String?
)
