package com.gkprojects.bookimggym.data.entities

data class Bookings(
    var userName : String,
    var gymService : String ,
    var timeStamp : String
)
