package com.gkprojects.bookimggym.data.entities

data class UserSubscriptions (
    var userName : String,
    var packageName : String ,
    var remainingSubs :Int
)