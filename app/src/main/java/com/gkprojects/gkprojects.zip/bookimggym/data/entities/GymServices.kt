package com.gkprojects.bookimggym.data.entities

data class GymServices(
    var name : String ,
    var maxNumberPeople : Int,
    var timeStamps : List <String>,
)
